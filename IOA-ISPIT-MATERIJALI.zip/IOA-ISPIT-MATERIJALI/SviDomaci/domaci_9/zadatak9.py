import numpy as np
import random


s = [2.424595205726587e-01, 1.737226395065819e-01, 1.315612759386036e-01,
     1.022985539042393e-01, 7.905975891960761e-02, 5.717509542148174e-02,
     3.155886625106896e-02, -6.242228581847679e-03, -6.565183775481365e-02,
     -8.482380513926287e-02, -1.828677714588237e-02, 3.632382803076845e-02,
     7.654845872485493e-02, 1.152250132891757e-01, 1.631742367154961e-01,
     2.358469152696193e-01, 3.650430801728451e-01, 5.816044173713664e-01,
     5.827732223753571e-01, 3.686942505423780e-01]

R0 = 15
N = 20
F = 0.8
CR = 0.9


def cost_fun(x):
    f = 0
    if np.sqrt(pow(x[0], 2) + pow(x[1], 2)) < R0 and np.sqrt(pow(x[2], 2) + pow(x[3], 2)) < R0:
        for i in range(N):
            xi = R0*np.cos(2*np.pi*i/N)
            yi = R0*np.sin(2*np.pi*i/N)
            f += pow(x[4]/np.sqrt(pow(xi - x[0], 2) + pow(yi - x[1], 2)) +
                     x[5]/np.sqrt(pow(xi - x[2], 2) + pow(yi - x[3], 2)) - s[i], 2)
    else:
        f = 100
    return f


pop_x = []
for i in range(60):
    xx = []
    xp1 = random.uniform(-15, 15)
    xx.append(xp1)
    yp1 = random.uniform(-15, 15)
    xx.append(yp1)
    xp2 = random.uniform(-15, 15)
    xx.append(xp2)
    yp2 = random.uniform(-15, 15)
    xx.append(yp2)
    A1 = random.uniform(-15, 15)
    xx.append(A1)
    A2 = random.uniform(-15, 15)
    xx.append(A2)
    pop_x.append(xx)

x = []
fx_min = 100
x_min = []
new_pop = []
for i in range(100000):
    new_pop.clear()
    for j in range(60):
        x = pop_x[j].copy()
        if i == 0 and j == 0:
            fx_min = cost_fun(x)
            x_min = x.copy()
        index_xa = random.randrange(0, 60)
        index_xb = random.randrange(0, 60)
        index_xc = random.randrange(0, 60)
        while index_xa == index_xb or index_xa == index_xc or index_xc == index_xb\
                or j == index_xa or j == index_xb or j == index_xc:
            index_xa = random.randrange(0, 60)
            index_xb = random.randrange(0, 60)
            index_xc = random.randrange(0, 60)
        xa = pop_x[index_xa].copy()
        xb = pop_x[index_xb].copy()
        xc = pop_x[index_xc].copy()
        z = []
        for k in range(6):
            elem_z = xa[k] + F * (xb[k] - xc[k])
            z.append(elem_z)
        R = np.random.randint(6)
        y = []
        for k in range(6):
            rk = random.random()
            if rk < CR or k == R:
                y.append(z[k])
            else:
                y.append(x[k])
        fy = cost_fun(y)
        fx = cost_fun(x)
        if fy < fx:
            new_pop.append(y)
        else:
            new_pop.append(x)
        if fx < fx_min:
            x_min = x.copy()
            fx_min = fx
        if fy < fx_min:
            x_min = y.copy()
            fx_min = fy
    if fx_min < pow(10, -14):
        break
    pop_x = new_pop.copy()

print("f(x) = ", fx_min)
print("x = ", x_min)
