#include<iostream>
#include <math.h> 
using namespace std;

int x0[31] = { 1,0,1,0,0,0,0,1,0,0,0,1,1,0,1,1,0,0,0,0,1,1,0,0,1,1,1,0,0,1,1 };

int isti, razliciti, p, i, raz, temp, k, j;

bool kroskorelacija(int *x) {
	int* xx = x0;
	for (i = 0; i < 31; i++) {
		if (i != 0) {
			temp = xx[30];
			for (k = 30; k > 0; k--)
				xx[k] = xx[k - 1];
			xx[0] = temp;
		}
		isti = 0;
		razliciti = 0;
		for (p = 0; p < 31; p++) {
			if (xx[p] == x[p])
				isti++;
			else
				razliciti++;
		}
		raz = isti - razliciti;
		if (raz <= -4 || raz >= 6)
			return false;
	}
	return true;
}

bool autokorelacija(int *x) {
	int xp[31];
	for (j = 0; j < 31; j++) {
		xp[j] = x[j];
	}
	for (i = 1; i < 31; i++) {
		temp = xp[30];
		for (k = 30; k > 0; k--)
			xp[k] = xp[k - 1];
		xp[0] = temp;
		isti = 0;
		razliciti = 0;
		for (p = 0; p < 31; p++) {
			if (xp[p] == x[p])
				isti++;
			else
				razliciti++;
		}
		raz = isti - razliciti;
		if (raz <= -18 || raz >= 12)
			return false;
	}
	return true;
}

int main() {
	int n = 31;
	int i, j;
	bool b;
	int k = 15;
	int *P = new int[k];

	for (int i = 0; i < k; i++)
		P[i] = i;
	int *x = new int[31];
	do {
		for (i = 0; i < n; i++)
			x[i] = 0;
		for (i = 0; i < k; i++)
			x[P[i]] = 1;
		if (kroskorelacija(x)) {
			if (autokorelacija(x)) {
				cout << "bin:  ";
				for (i = 0; i < 31; i++) {
					cout << x[i] << " ";
				}
				cout << "\t dec:  ";
				int dec = 0;
				for (i = 0; i < 31; i++) {
					dec += x[i] * pow(2, 30-i);
				}
				cout << dec;
				cout << endl;
			}
		}
		b = false;
		for (i = k - 1; i >= 0; i--) {
			if (P[i] < n - k + 1 + i) {
				P[i]++;
				for (j = i + 1; j < k; j++)
					P[j] = P[j - 1] + 1;
				b = true;
				break;
			} 
		}
	} while (b);

	if (P != NULL) delete[] P;
	cout << "KRAJ";
	int l;
	cin >> l;
	return 0;
}