import numpy as np
import scipy.special as sc
import matplotlib.pyplot as plt


x_niz = np.linspace(0, 20, 1000000)


#---------------------n=1------------------------------
a_1 = 0
b_1 = 0
a_2 = 0
b_2 = 0

br=0
for i in range(len(x_niz)-1):
    j = sc.spherical_jn(1, x_niz[i], derivative=False)

    if j<0:
        if b_1==0:
            b_1=x_niz[i]
            a_1=x_niz[i-1]
            continue
    if j>0 and b_1!=0:
        b_2 = x_niz[i]
        a_2 = x_niz[i-1]
        break


x1 = 0
for i in range(1000):
    x1 = (a_1+b_1)/2
    f_a = sc.spherical_jn(1, a_1 , derivative=False)
    f_b = sc.spherical_jn(1, b_1 , derivative=False)
    f_x = sc.spherical_jn(1, x1 , derivative=False)
    if f_x==0:
        break
    if f_a*f_x < 0:
        b_1 = x1
    elif f_b*f_x < 0:
        a_1 = x1

x2 = 0
for i in range(1000):
    x2 = (a_2+b_2)/2
    f_a = sc.spherical_jn(1, a_2 , derivative=False)
    f_b = sc.spherical_jn(1, b_2 , derivative=False)
    f_x = sc.spherical_jn(1, x2 , derivative=False)
    if f_x==0:
        break
    if f_a*f_x < 0:
        b_2 = x2
    elif f_b*f_x < 0:
        a_2 = x2
print("za n=1")
print(x1)
print(x2)

#---------------------n=2------------------------------
a_1 = 0
b_1 = 0
a_2 = 0
b_2 = 0


for i in range(len(x_niz)-1):
    j = sc.spherical_jn(2, x_niz[i], derivative=False)

    if j<0:
        if b_1==0:
            b_1=x_niz[i]
            a_1=x_niz[i-1]
            continue
    if j>0 and b_1!=0:
        b_2 = x_niz[i]
        a_2 = x_niz[i-1]
        break

x1 = 0
for i in range(1000):
    x1 = (a_1+b_1)/2
    f_a = sc.spherical_jn(1, a_1 , derivative=False)
    f_b = sc.spherical_jn(1, b_1 , derivative=False)
    f_x = sc.spherical_jn(1, x1 , derivative=False)
    if f_x==0:
        break
    if f_a*f_x < 0:
        b_1 = x1
    elif f_b*f_x < 0:
        a_1 = x1

x2 = 0
for i in range(1000):
    x2 = (a_2+b_2)/2
    f_a = sc.spherical_jn(1, a_2 , derivative=False)
    f_b = sc.spherical_jn(1, b_2 , derivative=False)
    f_x = sc.spherical_jn(1, x2 , derivative=False)
    if f_x==0:
        break
    if f_a*f_x < 0:
        b_2 = x2
    elif f_b*f_x < 0:
        a_2 = x2

print("za n=2")
print(x1)
print(x2)














