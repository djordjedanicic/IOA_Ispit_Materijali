import numpy as np
import scipy.special as sc
import matplotlib.pyplot as plt


x = np.linspace(0, 20, 1000)

for i in range(1, 3):
    J = sc.spherical_jn(i, x, derivative=False)
    plt.plot(x, J, label = r'n = ' + str(i))


plt.legend()
plt.title("BESELOVE FUNKCIJE", fontweight='bold', fontsize=20)
plt.xlabel('x', fontweight='bold', fontsize=16)
plt.ylabel('$J_n(x)$', fontweight='bold', fontsize=16)
plt.grid()
plt.show()
