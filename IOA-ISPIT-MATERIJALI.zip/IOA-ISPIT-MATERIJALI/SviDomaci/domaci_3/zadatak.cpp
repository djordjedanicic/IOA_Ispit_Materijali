#include <iostream>
#include <stdio.h>

using namespace std;
void SequenceToSpanningTree(int *P, int len, int *T) {
	int i, j, q = 0;
	int n = len + 2;
	int* V = new int[n];

	for (i = 0; i < n; i++)
		V[i] = 0;

	for (i = 0; i < len; i++)
		V[P[i]-1] += 1;

	for (i = 0; i < len; i++) {
		for (j = 0; j < n; j++) {
			if (V[j] == 0) {
				V[j] = -1;
				T[q++] = j + 1;
				T[q++] = P[i];
				V[P[i] - 1]--;
				break;
			}
		}
	}

	j = 0;
	for (i = 0; i < n; i++) {
		if (V[i] == 0 && j == 0) {
			T[q++] = i + 1;
			j++;
		}
		else if (V[i] == 0 && j == 1) {
			T[q++] = i + 1;
			break;
		}
	}

	delete[] V;
}

void variations_with_repetition(int n, int k) {
	int q;
	int *P = new int[k];
	for (int i = 0; i < k; i++)
		P[i] = 0;
	int niz[10][10] = {
	   { 0    ,374  ,200  ,223  ,108  ,178  ,252  ,285  ,240  ,356 },
	   { 374  ,0    ,255  ,166  ,433  ,199  ,135  ,95   ,136  ,17  },
	   { 200  ,255  ,0    ,128  ,277  ,821  ,180  ,160  ,131  ,247 },
	   { 223  ,166  ,128  ,0    ,430  ,47   ,52   ,84   ,40   ,155 },
	   { 108  ,433  ,277  ,430  ,0    ,453  ,478  ,344  ,389  ,423 },
	   { 178  ,199  ,821  ,47   ,453  ,0    ,91   ,110  ,64   ,181 },
	   { 252  ,135  ,180  ,52   ,478  ,91   ,0    ,114  ,83   ,117 },
	   { 285  ,95   ,160  ,84   ,344  ,110  ,114  ,0    ,47   ,78  },
	   { 240  ,136  ,131  ,40   ,389  ,64   ,83   ,47   ,0    ,118 },
	   { 356  ,17   ,247  ,155  ,423  ,181  ,117  ,78   ,118  ,0   }

	};
	char niz_gradova[10] = { 'A','B','C','D', 'E', 'F', 'G', 'H', 'I', 'J'};

	int Z[8] = {};
	for (int i = 0; i < k; i++) {
		Z[i] = P[i] + 1;
	}
	int len = sizeof(Z) / sizeof(Z[0]);
	int* T = new int[2 * (len + 1)];
	int* T_min = new int[2 * (len + 1)];
	int min = 2147483647;
	do {
		int br_i = 0, br_j=0;
		for (int i = 0; i < k; i++) {
			Z[i] = P[i] + 1;
		}
		SequenceToSpanningTree(Z, len, T);

		int sum = 0;
		int br_grana[10] = { 0,0,0,0,0,0,0,0,0,0 };
		for (int i = 0; i < 2 * (len + 1); i++) {
			if ((i + 1) % 2 == 0) {
				br_j = T[i]-1;
				sum += niz[br_i][ br_j];
				br_grana[br_i]++;
				br_grana[br_j]++;
			}
			else {
				br_i = T[i]-1;
			}
		}

		for (int i = 0; i < 10; i++) {
			if (br_grana[i] >= 4) {
				sum += 100 * (br_grana[i] - 3);
			}
		}

		if (sum < min) {
			min = sum;
			for (int i = 0; i < 2 * (len + 1); i++) {
				T_min[i] = T[i];
			}
		}
		q = k - 1;
		while (q >= 0) {
			P[q]++;
			if (P[q] == n) {
				P[q] = 0;
				q--;
			}
			else
				break;
		}
	} while (q >= 0);
	cout << "Min stablo: ";
	for (int i = 0; i < 2 * (len + 1); i++) {
	printf(" %c", niz_gradova[T_min[i]-1]);
	if ((i + 1) % 2 == 0 && i < 2 * len)
		printf("  - ");
}
	printf("\n");
	cout << "Min cena: "<< min<<endl;
	delete[] P;
}


int main() {
	

	variations_with_repetition(10, 8);



	int p;
	cin >> p;

	return 0;
}