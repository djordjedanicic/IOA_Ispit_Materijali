import numpy as np
import matplotlib.pyplot as plt

w = [4.870087623596191, 0.865561842918396, -0.084613919258118,
     -1.624826192855835, 4.926651000976563, -8.800392150878906,
     -6.936642646789551, -2.118837356567383, -5.492568492889404, 8.387107849121094]

y_out = []
y_training = []
x = np.linspace(-1, 1, 100)
for i in range(0, len(x)):
    sum_a = 0.0
    xk = []
    yk = []
    for j in range(0, 5):
        xk.append(w[j] * x[i])
        yk.append(np.tanh(xk[j]))
        sum_a += w[j+5] * yk[j]

    y_out.append(np.tanh(sum_a))
    y_training.append(0.5 * np.sin(np.pi * x[i]))

plt.plot(x, y_out, label=r'n = out')
plt.plot(x, y_training, label=r'n = training')


plt.legend()
plt.title("FUNKCIJE", fontweight='bold', fontsize=20)
plt.xlabel('x', fontweight='bold', fontsize=16)
plt.ylabel('$Y_n(x)$', fontweight='bold', fontsize=16)
plt.grid()
plt.show()
