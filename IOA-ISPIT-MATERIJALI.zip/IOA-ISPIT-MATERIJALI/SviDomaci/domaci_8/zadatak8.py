import matplotlib.pyplot as plt
import numpy as np
import random

s = [173669, 275487, 1197613, 1549805, 502334, 217684, 1796841, 274708,
     631252, 148665, 150254, 4784408, 344759, 440109, 4198037, 329673, 28602,
     144173, 1461469, 187895, 369313, 959307, 1482335, 2772513, 1313997, 254845,
     486167, 2667146, 264004, 297223, 94694, 1757457, 576203, 8577828, 498382,
     8478177, 123575, 4062389, 3001419, 196884, 617991, 421056, 3017627, 131936,
     1152730, 2676649, 656678, 4519834, 201919, 56080, 2142553, 326263, 8172117,
     2304253, 4761871, 205387, 6148422, 414559, 2893305, 2158562, 465972, 304078,
     1841018, 1915571]

const_64mb = 67108864

# Declaring rows
N = 2000
# Declaring columns
M = 64

x = [[0 for i in range(M)] for j in range(N)]

fx = []
fx_min = const_64mb
x_pok_min = []
fx_pok_min = const_64mb

fx_graf = []

fx_min_graf = const_64mb

f_arr_sum = []
for i in range(100000):
    f_arr_sum.append(0)

plt.figure()
x_label = []
for i in range(1, 100001):
    x_label.append(i)

for pok in range(20):
    fx_min = const_64mb
    fx_min_graf = const_64mb
    fx_graf.clear()
    for i in range(50):
        fx.clear()
        for j in range(2000):
            if i == 0:
                x[j] = np.random.randint(0, 2, 64, int)
            sum_ = 0
            for k in range(64):
                sum_ += s[k] * x[j][k]
            F = const_64mb - sum_
            if F < 0:
                F = const_64mb
            fx.append(F)
            if F < fx_min_graf:
                fx_min_graf = F
            fx_graf.append(fx_min_graf)
        # Bubble Sort
        for p in range(2000-1):
            for l in range(p+1, 2000):
                if fx[p] > fx[l]:
                    temp = fx[p]
                    fx[p] = fx[l]
                    fx[l] = temp

                    temp_x = x[p]
                    x[p] = x[l]
                    x[l] = temp_x
        if fx[0] < fx_min:
            fx_min = fx[0]
            if fx_min < fx_pok_min:
                fx_pok_min = fx_min
                x_pok_min = x[0]
        # Selekcija
        pom_x = []
        for d in range(400):
            pom_x.append(x[d])
        # Ukrstanje
        count = 0
        while count <= 1998:
            par1_x = np.random.randint(0, 400)
            par2_x = np.random.randint(0, 400)
            if par1_x != par2_x and random.random() < 0.8:
                presek = random.randrange(5, 60)
                for z in range(0, 64):
                    if z >= presek:
                        x[count][z] = pom_x[par2_x][z]
                    else:
                        x[count][z] = pom_x[par1_x][z]
                count += 1
                for z in range(0, 64):
                    if z >= presek:
                        x[count][z] = pom_x[par1_x][z]
                    else:
                        x[count][z] = pom_x[par2_x][z]
        # Mutacija
        for h in range(2000):
            if random.random() < 0.14:
                index_x = random.randrange(64)
                if x[h][index_x] == 1:
                    x[h][index_x] = 0
                else:
                    x[h][index_x] = 1
    for g in range(100000):
        f_arr_sum[g] += fx_graf[g]
    print(fx_min)
    plt.plot(x_label, fx_graf, label='n = ' + str(pok+1))
print("min fx = ", fx_pok_min)
print("min x = ", x_pok_min)

plt.legend()
plt.xlabel('Broj iteracija', fontweight='bold', fontsize=16)
plt.ylabel('f(x)', fontweight='bold', fontsize=16)
plt.yscale("Log")
plt.xscale("Log")
plt.show()


for i in range(100000):
    f_arr_sum[i] /= 20

plt.figure()
plt.plot(x_label, f_arr_sum, label='n = 1')
plt.xlabel('Broj iteracija', fontweight='bold', fontsize=16)
plt.ylabel('Srednja vrednost', fontweight='bold', fontsize=16)
plt.yscale("Log")
plt.xscale("Log")
plt.legend()
plt.show()
