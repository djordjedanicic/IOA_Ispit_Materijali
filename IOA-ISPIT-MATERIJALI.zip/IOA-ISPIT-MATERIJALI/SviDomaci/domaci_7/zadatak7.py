import matplotlib.pyplot as plt
import numpy as np
import random
from math import e

s = [173669, 275487, 1197613, 1549805, 502334, 217684, 1796841, 274708,
     631252, 148665, 150254, 4784408, 344759, 440109, 4198037, 329673, 28602,
     144173, 1461469, 187895, 369313, 959307, 1482335, 2772513, 1313997, 254845,
     486167, 2667146, 264004, 297223, 94694, 1757457, 576203, 8577828, 498382,
     8478177, 123575, 4062389, 3001419, 196884, 617991, 421056, 3017627, 131936,
     1152730, 2676649, 656678, 4519834, 201919, 56080, 2142553, 326263, 8172117,
     2304253, 4761871, 205387, 6148422, 414559, 2893305, 2158562, 465972, 304078,
     1841018, 1915571]


i_tot = 100000
const_64mb = 67108864
F_prev = const_64mb
F = const_64mb

h_min = 2
h_max = 62

fx_min = const_64mb

x = []
x_prev = []
index_arr = []

f_arr_sum = []

f_arr = []
x_label = []

for i in range(i_tot):
    f_arr_sum.append(0)

plt.figure()
for i in range(64):
    index_arr.append(i)

for i in range(20):
    x_label.clear()
    f_arr.clear()
    fx_min = const_64mb
    x_prev = np.random.randint(0, 2, 64, int)
    t_0 = 33554432
    sum_ = 0
    for k in range(64):
        sum_ += s[k] * x_prev[k]
    F_prev = const_64mb - sum_
    if F_prev < 0:
        F_prev = const_64mb
    fx_min = F_prev
    for j in range(i_tot):
        f_arr_sum[j] += fx_min
        f_arr.append(fx_min)
        x_label.append(j+1)
        hamming_distance = ((h_min-h_max)*j)/(i_tot-1) + h_max
        h_rand = random.sample(index_arr, int(hamming_distance))
        x = x_prev
        for z in range(int(hamming_distance)):
            if x[h_rand[z]] == 1:
                x[h_rand[z]] = 0
            else:
                x[h_rand[z]] = 1
        sum_ = 0
        for k in range(64):
            sum_ += s[k]*x[k]
        F = const_64mb - sum_
        if F < 0:
            F = const_64mb
        if F < F_prev:
            x_prev = x
            F_prev = F
        else:
            if F == F_prev:
                p = 0.5
            else:
                p = pow(e, (-(F - F_prev)/t_0))
            r = random.random()
            if r <= p:
                F_prev = F
                x_prev = x
        t_0 = t_0 * 0.95
        if F_prev < fx_min:
            fx_min = F_prev
    plt.plot(x_label, f_arr, label=r'n = ' + str(i+1))
    print("f(x) = ", F_prev)
    print("x[] = ", x_prev)
plt.legend()
plt.xlabel('Broj iteracija', fontweight='bold', fontsize=16)
plt.ylabel('f(x)', fontweight='bold', fontsize=16)
plt.yscale("Log")
plt.xscale("Log")
plt.show()

x_label.clear()
for i in range(i_tot):
    x_label.append(i+1)
    f_arr_sum[i] /= 20

plt.figure()
plt.plot(x_label, f_arr_sum, label='n = 1')
plt.xlabel('Broj iteracija', fontweight='bold', fontsize=16)
plt.ylabel('Srednja vrednost', fontweight='bold', fontsize=16)
plt.yscale("Log")
plt.xscale("Log")
plt.legend()
plt.show()


