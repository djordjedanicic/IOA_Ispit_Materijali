import numpy as np
import scipy.optimize as opt

f = np.array([310, 380, 350, 285, 310, 380, 350, 285, 310, 380, 350, 285])

A = np.array([[480, 650, 580, 390, 0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 480, 650, 580, 390, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0, 480, 650, 580, 390],
              [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
              [0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0],
              [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0],
              [0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
              [1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1]])

b = np.array([6800, 8700, 4300, 18, 15, 23, 12, 10, 16, 8])

rez = opt.linprog(-f, A, b, method="simplex")

fun = rez.fun
x_necelobrojna = rez.x

print("max kapacitet za necelobrojna resenja: ", fun)
print("necelobrojna resenja: ", x_necelobrojna)

x_c = np.around(x_necelobrojna)
x_celobrojna = []

for i in range(12):
    x_celobrojna.append(int(x_c[i]))

print("celobrojna resenja: ", x_celobrojna)

fmax = 0;
for i in range(12):
    fmax += f[i]*x_celobrojna[i]

print("max kapacitet za celobrojna resenja: ", fmax)

