#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <cmath>

using namespace std;

int next_permutation2(const int N, int *P) {
	int s;
	int* first = &P[0];
	int* last = &P[N - 1];
	int* k = last - 1;
	int* l = last;

	while (k > first) {
		if (*k < *(k + 1)) {
			break;
		}
		k--;
	}

	if (*k > *(k + 1)) {
		return 0;
	}

	while (l > k) {
		if (*l > *k) {
			break;
		}
		l--;
	}

	s = *k;
	*k = *l;
	*l = s;
	first = k + 1;

	while (first < last) {
		s = *first;
		*first = *last;
		*last = s;

		first++;
		last--;
	}

	return 1;
}

int main() {

	const int N = 12;
	int* P = new int[N];
	int* P_min = new int[N];

	double x[N] = { 62.0,57.5,51.7,67.9,57.7,54.2,46.0,34.7,45.7,34.7,28.4,33.4 };
	double y[N] = { 58.4,56.0,56.0,19.6,42.1,29.1,45.1,45.1,25.1,26.4,31.7,60.5 };

	for (int i = 0; i < N; i++) {
		P[i] = i;
	}

	double res1, res2;
	double res = 0;
	double min = 0;

	do
	{
		res = 0;
		for (int i = 0, j = 1; j < N; i++, j++) {
			res1 = pow(x[P[i]] - x[P[j]], 2);
			res2 = pow(y[P[i]] - y[P[j]], 2);
			res += sqrt(res1 + res2);
			if (res > min && min != 0) {
				break;
			}
		}
		if (res < min || min == 0) {
			min = res;
			for (int i = 0; i < N; i++) {
				P_min[i] = P[i];
			}
		}

	} while (next_permutation2(N, P));

	for (int i = 0; i < N; i++)
		printf("%3d", P_min[i] + 1);
	printf("\n");

	cout << min << endl;

	int j;
	cin >> j;

	delete[] P;
	delete[] P_min;

	return 0;
}