import random
import matplotlib.pyplot as plt


def cost_fun1(x1, x2):
    return 2*pow(x1, 2) + pow(x2, 2)


def cost_fun2(x1, x2):
    return -pow(x1-x2, 2)


def uslov(x1, x2):
    if x1*x2 + 0.25 >= 0:
        return 1
    return 0


f = []
for i in range(10000):
    pom = []
    x1 = random.uniform(-1, 1)
    x2 = random.uniform(-1, 1)
    pom.append(cost_fun1(x1, x2))
    pom.append(cost_fun2(x1, x2))
    f.append(pom)

f2 = []
count = 0
while True:
    pom = []
    x1 = random.uniform(-1, 1)
    x2 = random.uniform(-1, 1)
    if uslov(x1, x2) == 1:
        pom.append(cost_fun1(x1, x2))
        pom.append(cost_fun2(x1, x2))
        f2.append(pom)
        count = count + 1
    if count == 10000:
        break

dom1 = []
flag = 0
break_flag = 0
for i in range(10000):
    break_flag = 0
    for j in range(10000):
        if i != j:
            flag = 0
            if f[i][0] <= f[j][0]:
                if f[i][0] < f[j][0]:
                    flag = 1
                if f[i][1] <= f[j][1]:
                    if f[i][1] < f[j][1]:
                        flag = 1
                    if flag == 0:
                        break_flag = 1
                        break
                else:
                    if flag == 0:
                        break_flag = 1
                        break
            else:
                if f[i][1] >= f[j][1]:
                    break_flag = 1
                    break
    if break_flag == 0:
        dom1.append(f[i])

dom2 = []
for i in range(10000):
    break_flag = 0
    for j in range(10000):
        if i != j:
            flag = 0
            if f2[i][0] <= f2[j][0]:
                if f2[i][0] < f2[j][0]:
                    flag = 1
                if f2[i][1] <= f2[j][1]:
                    if f2[i][1] < f2[j][1]:
                        flag = 1
                    if flag == 0:
                        break_flag = 1
                        break
                else:
                    if flag == 0:
                        break_flag = 1
                        break
            else:
                if f2[i][1] >= f2[j][1]:
                    break_flag = 1
                    break
    if break_flag == 0:
        dom2.append(f2[i])

plt.figure()
for i in range(10000):
    plt.plot(f[i][0], f[i][1], color='blue', marker='*')
for i in range(len(dom1)):
    plt.plot(dom1[i][0], dom1[i][1], color='red', marker='*')
plt.show()

plt.figure()
for i in range(10000):
    plt.plot(f2[i][0], f2[i][1], color='blue', marker='*')
for i in range(len(dom2)):
    plt.plot(dom2[i][0], dom2[i][1], color='red', marker='*')
plt.show()


