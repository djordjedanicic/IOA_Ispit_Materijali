import numpy as np
import random

A = [1, 5, 1]
B = [3, 2, 0]
C = [5, 7, 1]
D = [6, 3, 3]


def cost_fun(x):
    a_s1 = np.sqrt(pow(x[0] - A[0], 2) + pow(x[1] - A[1], 2) + pow(x[2] - A[2], 2))
    b_s1 = np.sqrt(pow(x[0] - B[0], 2) + pow(x[1] - B[1], 2) + pow(x[2] - B[2], 2))
    c_s2 = np.sqrt(pow(x[3] - C[0], 2) + pow(x[4] - C[1], 2) + pow(x[5] - C[2], 2))
    d_s2 = np.sqrt(pow(x[3] - D[0], 2) + pow(x[4] - D[1], 2) + pow(x[5] - D[2], 2))
    s1_s2 = np.sqrt(pow(x[0] - x[3], 2) + pow(x[1] - x[4], 2) + pow(x[2] - x[5], 2))
    return a_s1 + b_s1 + c_s2 + d_s2 + s1_s2


x = []
p_best = []
udalj_min = 1000000
g_best = []
for i in range(60):
    xx = []
    x1 = random.uniform(-7, 7)
    xx.append(x1)
    y1 = random.uniform(-7, 7)
    xx.append(y1)
    c1 = random.uniform(-7, 7)
    xx.append(c1)
    x2 = random.uniform(-7, 7)
    xx.append(x2)
    y2 = random.uniform(-7, 7)
    xx.append(y2)
    c2 = random.uniform(-7, 7)
    xx.append(c2)
    x.append(xx)
    p_best.append(xx)

v = []
v_max = 1.5
for i in range(60):
    v_elem = []
    v0 = random.uniform(-v_max, v_max)
    v_elem.append(v0)
    v1 = random.uniform(-v_max, v_max)
    v_elem.append(v1)
    v2 = random.uniform(-v_max, v_max)
    v_elem.append(v2)
    v3 = random.uniform(-v_max, v_max)
    v_elem.append(v3)
    v4 = random.uniform(-v_max, v_max)
    v_elem.append(v4)
    v5 = random.uniform(-v_max, v_max)
    v_elem.append(v5)
    v.append(v_elem)

# w = 0.8
w = 0.729
# c1 = 1.5
c1 = 1.494
# c2 = 1.5
c2 = 1.494


new_x = []
new_v = []
for i in range(10000):
    new_x.clear()
    new_v.clear()
    for j in range(60):
        udalj = cost_fun(x[j])
        if udalj < udalj_min:
            udalj_min = udalj
            g_best = x[j]
        v_tek = []
        for p in range(6):
            v_tek.append(w*v[j][p] + c1 * random.random() * (p_best[j][p] - x[j][p]) + c2 * random.random() * (g_best[p] - x[j][p]))
            if v_tek[p] < -v_max:
                v_tek[p] = -v_max
            if v_tek[p] > v_max:
                v_tek[p] = v_max
        new_v.append(v_tek)
        new_x_elem = []
        for p in range(6):
            new_x_elem.append(x[j][p] + new_v[j][p])
        cost_p_best = cost_fun(p_best[j])
        cost_new_x_elem = cost_fun(new_x_elem)
        if cost_new_x_elem < cost_p_best:
            p_best[j] = new_x_elem
        new_x.append(new_x_elem)
    v = new_v.copy()
    x = new_x.copy()

S1 = [g_best[0], g_best[1], g_best[2]]
S2 = [g_best[3], g_best[4], g_best[5]]

print("S1 = ", S1)
print("S2 = ", S2)

print("Min duzina = ", udalj_min)